package com.ktcp.intentsdk.demo.protocol;

import org.json.JSONObject;

public class ProtocolGetter {
    public static String getReqContext(JSONObject protocol) {
        JSONObject jsonObj = protocol.optJSONObject("head");
        return jsonObj != null ? jsonObj.optString("req_context") : "";
    }

    public static String getService(JSONObject protocol) {
        JSONObject jsonObj = protocol.optJSONObject("intent");
        return jsonObj != null ? jsonObj.optString("service") : "";
    }

    public static String getOperation(JSONObject protocol) {
        JSONObject jsonObj = protocol.optJSONObject("intent");
        return jsonObj != null ? jsonObj.optString("operation") : "";
    }

    public static String getTips(JSONObject protocol) {
        JSONObject jsonObj = protocol.optJSONObject("content_info");
        return jsonObj != null ? jsonObj.optString("tips") : "";
    }
}
