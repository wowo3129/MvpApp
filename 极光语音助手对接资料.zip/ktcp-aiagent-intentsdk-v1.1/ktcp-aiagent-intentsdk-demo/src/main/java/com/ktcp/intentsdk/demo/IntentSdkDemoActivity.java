package com.ktcp.intentsdk.demo;

import android.os.Bundle;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.v7.app.AppCompatActivity;
import android.widget.TextView;

import com.ktcp.aiagent.intentsdk.IVoiceIntentApiListener;
import com.ktcp.aiagent.intentsdk.OpenInterfaceResult;
import com.ktcp.aiagent.intentsdk.VoiceIntentClient;
import com.ktcp.aiagent.intentsdk.VoiceIntentConfig;
import com.ktcp.intentsdk.demo.protocol.handler.AppHandler;
import com.ktcp.intentsdk.demo.protocol.handler.OtherHandler;
import com.ktcp.intentsdk.demo.protocol.handler.VideoHandler;
import com.ktcp.intentsdk.demo.scene.CommonSceneInfoInjector;
import com.ktcp.intentsdk.demo.scene.iot.IotSceneInfoInjector;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;
import com.ktcp.intentsdk.demo.utils.JSONFormatter;

import org.json.JSONObject;

public class IntentSdkDemoActivity extends AppCompatActivity implements DemoPrinter.IPrinterInterface {

    private TextView mMessageBox;
    private TextView mProtocolBox;
    private Handler mHandler = new Handler();

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_intent_sdk_demo);
        mMessageBox = findViewById(R.id.message_box);
        mProtocolBox = findViewById(R.id.protocol_box);
        DemoPrinter.setPrinterImpl(this);

        // 设置SDK的调试模式，控制是否打印Log等行为
        // 注意！！！APP发布版本需要关闭该开关
        VoiceIntentClient.setDebug(true);

        // 初始化IntentSDK
        // openId与意图分发规则与包名绑定，请与SDK提供方联系根据集成APP包名分配openId
        VoiceIntentConfig config = new VoiceIntentConfig();
        config.openId = "192439176ad1e4ec728a01c92556cb7d";  // 与com.ktcp.intentsdk.demo包名绑定
        VoiceIntentClient.init(getApplicationContext(), config, intentApiListener);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        DemoPrinter.setPrinterImpl(null);

        // 释放SDK资源
        VoiceIntentClient.release();
    }

    private IVoiceIntentApiListener intentApiListener = new IVoiceIntentApiListener() {
        @Override
        public void onInitialization(int code, String msg, String params) {
            // 初始化结果回调处理，注册需要的协议处理器
            if (code == OpenInterfaceResult.SUCCESS) {
                DemoPrinter.printMessage("VoiceIntentClient init success");

                // 初始化成功，注册关注领域的意图协议处理器
                VoiceIntentClient.registerProtocolHandler(new VideoHandler());
                VoiceIntentClient.registerProtocolHandler(new AppHandler());
                VoiceIntentClient.registerProtocolHandler(new OtherHandler());

                // 注册需要提供的场景信息的注入器
                VoiceIntentClient.registerSceneInfoInjector(new CommonSceneInfoInjector());
                VoiceIntentClient.registerSceneInfoInjector(new IotSceneInfoInjector());
            } else {
                DemoPrinter.printMessage("VoiceIntentClient init error: " + code + " " + msg);
            }
        }
    };

    @Override
    public void printMessage(final String message) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                mMessageBox.append(message + "\n");
                int scrollAmount = mMessageBox.getLayout().getLineTop(mMessageBox.getLineCount())
                        - mMessageBox.getHeight() + mMessageBox.getPaddingBottom();
                if (scrollAmount > 0) {
                    mMessageBox.scrollTo(0, scrollAmount);
                } else {
                    mMessageBox.scrollTo(0, 0);
                }
            }
        });
    }

    @Override
    public void printProtocol(final JSONObject protocol) {
        mHandler.post(new Runnable() {
            @Override
            public void run() {
                String json = JSONFormatter.formatJson(String.valueOf(protocol));
                mProtocolBox.setText(json);
            }
        });
    }
}
