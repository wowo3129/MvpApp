package com.ktcp.intentsdk.demo.utils;


import org.json.JSONObject;

import java.lang.ref.WeakReference;

public class DemoPrinter {

    private static WeakReference<IPrinterInterface> implRef;

    public static void setPrinterImpl(IPrinterInterface impl) {
        implRef = impl != null ? new WeakReference<>(impl) : null;
    }

    public static void printMessage(String message) {
        IPrinterInterface impl = implRef != null ? implRef.get() : null;
        if (message != null && impl != null) {
            impl.printMessage(message);
        }
    }

    public static void printProtocol(JSONObject protocol) {
        IPrinterInterface impl = implRef != null ? implRef.get() : null;
        if (protocol != null && impl != null) {
            impl.printProtocol(protocol);
        }
    }

    public interface IPrinterInterface {
        void printMessage(String message);
        void printProtocol(JSONObject protocol);
    }
}
