package com.ktcp.intentsdk.demo.protocol.handler;

import android.util.Log;

import com.ktcp.aiagent.intentsdk.VoiceIntentClient;
import com.ktcp.aiagent.intentsdk.protocol.IProtocolHandler;
import com.ktcp.intentsdk.demo.protocol.ProtocolGetter;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;

import org.json.JSONObject;

public class OtherHandler implements IProtocolHandler<JSONObject> {
    @Override
    public String getTag() {
        return "OtherHandler";
    }

    @Override
    public void onRegistered() {
    }

    @Override
    public void onUnregistered() {
    }

    @Override
    public boolean handleProtocol(JSONObject protocol) {
        String service = ProtocolGetter.getService(protocol);
        String operation = ProtocolGetter.getOperation(protocol);
        String message = "handleProtocol intent=[" + service + ":" + operation + "]";
        Log.i(getTag(), message);
        DemoPrinter.printMessage(message);
        DemoPrinter.printProtocol(protocol);
        VoiceIntentClient.feedback(true, "正在处理" + service + "领域意图");
        return true;
    }
}
