package com.ktcp.intentsdk.demo.scene.iot.model;

import com.google.gson.annotations.SerializedName;

/**
 * Created by zitachen on 2019/3/31.
 */
public class IotProvider
{
    /**
     * IOT提供商名称
     */
    @SerializedName("provider_name")
    public String providerName;
}
