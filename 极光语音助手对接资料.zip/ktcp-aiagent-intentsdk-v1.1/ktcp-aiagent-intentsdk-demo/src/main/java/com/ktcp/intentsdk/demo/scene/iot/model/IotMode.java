package com.ktcp.intentsdk.demo.scene.iot.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by zitachen on 2019/3/28.
 */
public class IotMode
{
    /**
     * 模式ID
     */
    @SerializedName("mode_id")
    public String modeId;

    /**
     * 模式名称
     */
    @SerializedName("mode_name")
    public String modeName;

    /**
     * 模式别名列表
     */
    @SerializedName("alias_name_list")
    public List<String> aliasNameList;
}
