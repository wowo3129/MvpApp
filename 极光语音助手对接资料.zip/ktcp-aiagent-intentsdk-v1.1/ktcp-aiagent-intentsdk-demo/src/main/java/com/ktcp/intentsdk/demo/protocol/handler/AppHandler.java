package com.ktcp.intentsdk.demo.protocol.handler;

import android.util.Log;

import com.ktcp.aiagent.intentsdk.VoiceIntentClient;
import com.ktcp.aiagent.intentsdk.protocol.IProtocolHandler;
import com.ktcp.intentsdk.demo.protocol.ProtocolGetter;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;

import org.json.JSONObject;

public class AppHandler implements IProtocolHandler<JSONObject> {
    @Override
    public String getTag() {
        return "AppHandler";
    }

    @Override
    public void onRegistered() {
    }

    @Override
    public void onUnregistered() {
    }

    @Override
    public boolean handleProtocol(JSONObject protocol) {
        String service = ProtocolGetter.getService(protocol);
        if ("APP".equals(service)) {
            String operation = ProtocolGetter.getOperation(protocol);
            String message = "handleProtocol intent=[" + service + ":" + operation + "]";
            Log.i(getTag(), message);

            boolean success = false;
            switch (operation) {
                case "STORE":
                    success = true;
                    break;
                case "LAUNCHER":
                    success = true;
                    break;
                case "DOWNLOAD":
                    success = true;
                    break;
                case "DELETE":
                    success = true;
                    break;
                default:
                    break;
            }

            DemoPrinter.printMessage(message);
            DemoPrinter.printProtocol(protocol);

            if (success) {
                VoiceIntentClient.feedback(success, "正在处理APP领域意图");
            } else {
                VoiceIntentClient.feedback(success, "未知APP领域意图");
            }

            // 已处理返回true
            return true;
        }

        // 未处理返回false
        return false;
    }
}
