package com.ktcp.intentsdk.demo.scene;

import com.ktcp.aiagent.intentsdk.protocol.ISceneInfoInjector;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;

import org.json.JSONObject;

import java.util.HashMap;
import java.util.Map;

public class CommonSceneInfoInjector implements ISceneInfoInjector {
    @Override
    public void onRegistered() {

    }

    @Override
    public void onUnregistered() {

    }

    @Override
    public Map<String, String> injectCommonInfo() {
        Map<String, String> map = new HashMap<>();
        map.put("info1", "I am IntentSDK Demo");
        DemoPrinter.printMessage("injectCommonInfo: " + map);
        return map;
    }

    @Override
    public Map<String, String[]> injectCommands() {
        return null;
    }

    @Override
    public JSONObject injectIotInfo() {
        return null;
    }
}
