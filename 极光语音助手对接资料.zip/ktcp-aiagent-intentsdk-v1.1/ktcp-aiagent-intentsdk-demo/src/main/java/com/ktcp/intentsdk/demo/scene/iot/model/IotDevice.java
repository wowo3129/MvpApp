package com.ktcp.intentsdk.demo.scene.iot.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

/**
 * Created by zitachen on 2018/10/10.
 */
public class IotDevice {
    /**
     * 设备ID
     */
    @SerializedName("device_name")
    public String deviceName;

    /**
     * 设备名称
     */
    @SerializedName("device_id")
    public String deviceId;

    /**
     * 设备类型
     */
    @SerializedName("device_type")
    public String deviceType;

    /**
     * 设备位置
     */
    @SerializedName("postition")
    public String postition;

    /**
     * 设备别名列表
     */
    @SerializedName("alias_name_list")
    public List<String> aliasNameList;

    /**
     * 设备支持的控制功能列表
     */
    @SerializedName("ctrl_list")
    public List<String> ctrlList;
}
