package com.ktcp.intentsdk.demo.protocol.handler;

import android.util.Log;

import com.ktcp.aiagent.intentsdk.VoiceIntentClient;
import com.ktcp.aiagent.intentsdk.protocol.IProtocolHandler;
import com.ktcp.intentsdk.demo.protocol.ProtocolGetter;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;

import org.json.JSONObject;

public class VideoHandler implements IProtocolHandler<JSONObject> {
    @Override
    public String getTag() {
        return "VideoHandler";
    }

    @Override
    public void onRegistered() {
    }

    @Override
    public void onUnregistered() {
    }

    @Override
    public boolean handleProtocol(JSONObject protocol) {
        String service = ProtocolGetter.getService(protocol);
        if ("VIDEO".equals(service)) {
            String operation = ProtocolGetter.getOperation(protocol);
            String message = "handleProtocol intent=[" + service + ":" + operation + "]";
            Log.i(getTag(), message);

            boolean success = false;
            switch (operation) {
                case "SEARCH":
                    success = true;
                    break;
                case "CHANNEL":
                    success = true;
                    break;
                case "SPORTS":
                    success = true;
                default:
                    break;
            }

            DemoPrinter.printMessage(message);
            DemoPrinter.printProtocol(protocol);

            if (success) {
                VoiceIntentClient.feedback(success, "正在处理视频领域意图");
            } else {
                VoiceIntentClient.feedback(success, "未知视频领域意图");
            }

            // 已处理返回true
            return true;
        }

        // 未处理返回false
        return false;
    }
}
