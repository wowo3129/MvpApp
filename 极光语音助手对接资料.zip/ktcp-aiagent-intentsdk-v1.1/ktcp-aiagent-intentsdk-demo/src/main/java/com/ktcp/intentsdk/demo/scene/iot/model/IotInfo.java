package com.ktcp.intentsdk.demo.scene.iot.model;

import com.google.gson.annotations.SerializedName;

import java.util.List;

public class IotInfo {

    /**
     * 用户已添加的设备列表
     */
    @SerializedName("device_list")
    public List<IotDevice> deviceList;

    /**
     * 模式列表
     */
    @SerializedName("mode_list")
    public List<IotMode> modeList;

    /**
     * IOT提供商标识
     */
    @SerializedName("provider_info")
    public IotProvider provider;
}
