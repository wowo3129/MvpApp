package com.ktcp.intentsdk.demo.scene.iot;


import com.google.gson.Gson;
import com.ktcp.aiagent.intentsdk.protocol.ISceneInfoInjector;
import com.ktcp.intentsdk.demo.scene.iot.model.IotDevice;
import com.ktcp.intentsdk.demo.scene.iot.model.IotInfo;
import com.ktcp.intentsdk.demo.scene.iot.model.IotProvider;
import com.ktcp.intentsdk.demo.utils.DemoPrinter;

import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;


public class IotSceneInfoInjector implements ISceneInfoInjector {
    @Override
    public void onRegistered() {

    }

    @Override
    public void onUnregistered() {

    }

    @Override
    public Map<String, String> injectCommonInfo() {
        return null;
    }

    @Override
    public Map<String, String[]> injectCommands() {
        return null;
    }

    @Override
    public JSONObject injectIotInfo() {
        JSONObject iotJson = getIotInfo();
        DemoPrinter.printMessage("injectIotInfo: " + iotJson);
        return iotJson;
    }

    private List<IotDevice> getDevices() {
        List<IotDevice> devices = new ArrayList<>();

        IotDevice device = new IotDevice();
        device.deviceId = "123456";
        device.deviceName = "客厅灯";
        device.deviceType = "";
        device.aliasNameList = Arrays.asList("客厅小灯", "客厅智能灯");
        device.ctrlList = Arrays.asList("TurnOn", "TurnOff");

        devices.add(device);
        return devices;
    }

    private JSONObject getIotInfo() {
        IotProvider iotProvider = new IotProvider();
        iotProvider.providerName = "xiaowei";

        IotInfo iotInfo = new IotInfo();
        iotInfo.provider = iotProvider;
        iotInfo.deviceList = getDevices();
        iotInfo.modeList = null;

        try {
            String jsonString = new Gson().toJson(iotInfo);
            return new JSONObject(jsonString);
        } catch (JSONException e) {
            e.printStackTrace();
        }

        return null;
    }
}
